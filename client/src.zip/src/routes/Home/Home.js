// src/routes/Home/Home.js
import React from "react";
import "./Home.css";
import HeroImage from "../../components/HeroImage/HeroImage";
import ImageGallery from "../../components/ImageGallery/ImageGallery";

const Home = () => {
  return (
    <div style={{}}>
      <HeroImage />
      <ImageGallery />
    </div>
  );
};

export default Home;
