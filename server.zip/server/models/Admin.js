const mongoose = require("mongoose");

const AdminSchema = new mongoose.Schema({
  name: { type: String, required: true },
  surname: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

module.exports = mongoose.model("Admin", AdminSchema);

// const mongoose = require('mongoose');

// const AdminSchema = new mongoose.Schema({
//     name: { type: String, required: true },
//     surname: { type: String, required: true },
//     email: { type: String, required: true, unique: true },
//     password: { type: String, required: true }
// });

// module.exports = mongoose.model('Admin', AdminSchema);
